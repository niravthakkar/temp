

/* TODO : the required functions if the compiler does not have variadic macros */
